document.addEventListener('DOMContentLoaded', () => {
    const productList = document.getElementById('products');

    function loadProducts() {
        const products = JSON.parse(localStorage.getItem('products')) || [];
        products.forEach((product, index) => {
            const productHtml = `
                <div class="product">
                    <img src="${product.imageSrc}" alt="${product.name}">
                    <div>
                        <h3>${product.name}</h3>
                        <p>Category: ${product.category}</p>
                        <p>Product Code: ${product.code}</p>
                        <p>Price: $${product.price}</p>
                        <p>Attribute 1: ${product.attribute1}</p>
                        <p>Attribute 2: ${product.attribute2}</p>
                        <p>Attribute 3: ${product.attribute3}</p>
                    </div>
                    <button class="deleteProduct" data-index="${index}">Delete</button>
                </div>
            `;
            productList.innerHTML += productHtml;
        });
        addDeleteEventListeners();
    }

    function addDeleteEventListeners() {
        const deleteButtons = document.querySelectorAll('.deleteProduct');
        deleteButtons.forEach(button => {
            button.addEventListener('click', deleteProduct);
        });
    }

    function deleteProduct(e) {
        const index = e.target.dataset.index;
        let products = JSON.parse(localStorage.getItem('products')) || [];
        products.splice(index, 1);
        localStorage.setItem('products', JSON.stringify(products));
        e.target.closest('.product').remove();
    }

    loadProducts();
});