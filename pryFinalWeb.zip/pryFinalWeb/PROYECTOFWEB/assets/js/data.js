const productos = [
    { 
        nombre: "adidas superstar",
        precio: "90.000",
        categoria: "DEPORTIVO",
        codigo: "Ad01jpga",
        img: "https://assets.adidas.com/images/w_383,h_383,f_auto,q_auto,fl_lossy,c_fill,g_auto/2756c1aa61094ec283101d2910ed4196_9366/tenis-adidas-vl-court-3.0-low-skateboarding.jpg",
        provedores: "NACIONALES",
        color: "BCO/NG",
        calidad: "AAA",
    },
    { 
        nombre: "adidas superstar",
        precio: "80.000",
        categoria: "",
        codigo: "Ad02jpga",
        img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/bd8f7ae244774097a60bab0300bea8de_9366/Tenis_Superstar_UNISEX_Negro_EF5394_01_standard.jpg",
        provedores: "",
        color: "NG/BCO",
        calidad: "AAA",
    },
    { 
         
        nombre:"adidas superstar",
        precio: "80.000",
        categoria:"",
        codigo: "Ad03jpga",
        img: "https://falabella.scene7.com/is/image/FalabellaCO/4321050_1?wid=800&hei=800&qlt=70",
        provedores:"NACIONALES",
        color:" ",
        calidad :"AAA",
       },
       { 
         
        nombre:"adidas superstar",
        precio: "80.000",
        categoria:"",
        codigo: "Ad04jpga",
        img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/2e7642ed30e04c47a57faf680163ac9e_9366/Tenis_Superstar_PRIDE_RM_Blanco_ID7493_01_standard.jpg",
        provedores:"",
        color:" ",
        calidad :"",
       },

       { 
         
        nombre:"YEZZY",
        precio: "90.000",
        categoria:"DEPORTIVOS",
        codigo: "Ad08jpga",
        img: "https://nevnev.co.il/wp-content/uploads/2022/06/Adidas-Yeezy-Boost-350-V2-Dazzling-Blue-nevnev.co_.il-3.jpg",
        provedores:"NACIONALES",
        color:"BLACO/AZUL",
        calidad :"AAA",
       },

       { 
     
        nombre:"YEZZY",
        precio: "90.000",
        categoria:"DEPORTIVOS",
        codigo: "Ad09jpga",
        img: "https://acdn.mitiendanube.com/stores/001/750/876/products/modelo-tenis-site-copia41-3deae402cae909e27216636045119814-1024-1024.jpg",
        provedores:"NACIONALES",
        color:" AZUL" ,
        calidad :"AAA",
       },

       { 
     
        nombre:"YEZZY",
        precio: "90.000",
        categoria:"DEPORTIVOS",
        codigo: "Ad10jpga",
        img: "https://cdn-images.farfetch-contents.com/15/47/78/06/15477806_27920430_600.jpg",
        provedores:"NACIONALES",
        color:" ",
        calidad :"AAA",
       },
    { 
         
        nombre:"YEZZY",
        precio: "90.000",
        categoria:"DEPORTIVOS",
        codigo: "Ad06jpga",
        img: "https://images.stockx.com/images/adidas-Yeezy-Boost-350-V2-Onyx-Product.jpg?fit=fill&bg=FFFFFF&w=700&h=500&fm=webp&auto=compress&q=90&dpr=2&trim=color&updated_at=1656420652",
        provedores:"NACIONALES",
        color:"NEGRA",
        calidad :"AAA",
       },

       { 
         
        nombre:"ZAMBA",
        precio: "100.00",
        categoria:"CLASICAS",
        codigo: "Ad11jpga",
        img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/3bbecbdf584e40398446a8bf0117cf62_9366/Tenis_Samba_OG_Blanco_B75806_01_standard.jpg",
        provedores:"NACIONALES",
        color:" BLANCA/NEGRA/CAFE",
        calidad :"1.1",
       },

       { 
     
        nombre:"ZAMBA",
        precio: "100.00",
        categoria:"CLASICAS",
        codigo: "Ad12jpga",
        img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4a46e180c40643c8b436af9c017a4615_9366/Tenis_Samba_adidas_Originals_Verde_ID2054_01_standard.jpg",
        provedores:"NACIONALES",
        color:"VERDE/BLANCO/CAFE",
        calidad :"1.1",
       },

       { 
     
        nombre:"ZAMBA",
        precio: "100.00",
        categoria:"CLASICAS",
        codigo: "Ad13jpga",
        img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/eb4fe70570824a5993f305aca11473de_9366/Tenis_Samba_Verde_IG1242_01_standard.jpg",
        provedores:"NACIONALES",
        color:" VERDE ",
        calidad :"1.1",
       },

       { 
     
        nombre:"ZAMBA",
        precio: "100.00",
        categoria:"CLASICAS",
        codigo: "Ad14jpga",
        img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/d4f828e8d13044c484a0f3e617b1d80f_9366/Tenis_Samba_Premium_Gris_IE4957_01_standard.jpg",
        provedores:"NACIONALES",
        color:" GRIS",
        calidad :"1.1",
       },

       { 
     
        nombre:"ZAMBA",
        precio: "100.000",
        categoria:"CLASICAS",
        codigo: "Ad15jpga",
        img: "https://assets.adidas.com/images/w_600,f_auto,q_auto/4c70105150234ac4b948a8bf01187e0c_9366/Tenis_Samba_OG_Negro_B75807_01_standard.jpg",
        provedores:"NACIONALES",
        color:" NEGRAS",
        calidad :"1.1",
        

       },

      
       { 
     
        nombre:"Puma Roma",
        precio: "120.00",
        categoria:"CLASICAS",
        codigo: "Pm01jpga",
        img: "https://ss237.liverpool.com.mx/xl/1123801098.jpg",
        provedores:"",
        color:"NEGRAS",
        calidad :"1.1",

       },

       { 
     
        nombre:"Puma Roma",
        precio: "120.000",
        categoria:"Clasica",
        codigo: "Pm02jpga",
        img: "https://unicosmoderna.com/cdn/shop/products/TENIS-ROMA-BASIC-353572-58-HOMBRE-BLANCO-B.jpg",
        provedores:"Nacionales",
        color:"Blanco",
        calidad :"1.1",

       },
    

       { 
     
        nombre:"Puma Roma",
        precio: "120.000",
        categoria:"Clasica",
        codigo: "Pm03jpga",
        img: "https://i.ebayimg.com/thumbs/images/g/5jIAAOSwFbZjeDGJ/s-l640.jpg",
        provedores:"Nacionales",
        color:"Azul",
        calidad :"1.1",

       },
    

       { 
     
        nombre:"Puma Roma",
        precio: "120.000",
        categoria:"Clasica",
        codigo: "Pm04jpga",
        img: "https://i.ebayimg.com/thumbs/images/g/x8sAAOSwHkdjSfNO/s-l640.jpg",
        provedores:"NACIONALES",
        color:"ARCOIRIS",
        calidad :"1.1",

       },
    

       { 
     
        nombre:"Puma Roma",
        precio: "",
        categoria:"Clasica",
        codigo: "Pm05jpga",
        img: "https://resources.claroshop.com/medios-plazavip/s2/11633/3767207/628ffc7f4b773-7261cf23-b6fb-4301-b8cd-c5037979de6b-1600x1600.jpg",
        provedores:"",
        color:" NEGRA/ROJO ",
        calidad :"1.1",

       },
    

       { 
     
        nombre:"Puma California",
        precio: "100.000",
        categoria:"Clasicas",
        codigo: "Pm06jpga",
        img: "https://s7d9.scene7.com/is/image/zumiez/pdp_hero/PUMA-California-Exotic-Tan%2C-Gum-/u0026-White-Shoes-_302817.jpg",
        provedores:"Nacionales",
        color:"blanco",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma California",
        precio: "100.000",
        categoria:"clasicas",
        codigo: "Pm07jpga",
        img: "https://t-static.dafiti.com.br/y15P9TZ1g673TR2jvTc23K-WaJY=/400x580/smart/filters:quality(90)/static.dafiti.com.co/p/puma-0432-1905601-3-product.jpg",
        provedores:"Nacionales",
        color:" blanco/negro",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma California",
        precio: "100.000",
        categoria:"CLasica",
        codigo: "Pm08jpga",
        img: "https://scene7.zumiez.com/is/image/zumiez/image/PUMA-California-Black-%26-White-Shoes-_308420.jpg",
        provedores:"Nacionales",
        color:"negra/blanca",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma California",
        precio: "100.000",
        categoria:"Clasica",
        codigo: "Pm09jpga",
        img: "https://i.pinimg.com/564x/38/f8/fb/38f8fb9c1ae2559e03af9462cd4bcd4d.jpg",
        provedores:"Nacionales",
        color:" gris",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma California",
        precio: "100.000",
        categoria:"Clasicas",
        codigo: "Pm10jpga",
        img:" https://di2ponv0v5otw.cloudfront.net/posts/2023/04/06/642eb66b27539d699055bf52/m_642eb67bbd66cd9bdcdc6691.jpeg",
        provedores:"NAcionales",
        color:"Blanco/Azul",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma California",
        precio: "100.000",
        categoria:"Clasica",
        codigo: "Pm11jpga",
        img: "https://scene7.zumiez.com/is/image/zumiez/pdp_hero/PUMA-California-Casual-zapatos-blancos-y-rojos--_296520.jpg",
        provedores:"Nacional",
        color:"Blaco/Rojo ",
        calidad :"AAA",

       },
       
       { 
         
        nombre:"Puma Roma bmw",
        precio: "110.000",
        categoria:"Clasica",
        codigo: "Pm12jpga",
        img: "https://i.ebayimg.com/thumbs/images/g/qVIAAOSwBxhkQu24/s-l300.jpg",
        provedores:"Nacionales",
        color:"Negro/Rojo ",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma Ferrary",
        precio: "110.000",
        categoria:"Clasica",
        codigo: "Pm13jpga",
        img: "https://www.genetic.com.mx/cdn/shop/products/025475_1_600x600.jpg",
        provedores:"Nacionales",
        color:"Negra/Roja",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Puma ferrary",
        precio: "110.000",
        categoria:"Clasica",
        codigo: "Pm14jpga",
        img: "https://i5.walmartimages.com.mx/mg/gm/3pp/asr/9985913c-4522-453a-8beb-98d41ee0e444.1d36c283eeed1297c75eaf3f7342280c.jpeg",
        provedores:"Nacionales",
        color:" Rojo",
        calidad :"AAA",

       },
    

       { 
     
        nombre:"Pma Ferrary",
        precio: "110.000",
        categoria:"Clasica",
        codigo: "Pm15jpga",
        img: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_450,h_450/global/306869/02/sv01/fnd/EEA/fmt/png",
        provedores:"",
        color:" ",
        calidad :"",

       },

       { 
     
        nombre:"Jordan R13",
        precio: "",
        categoria:"",
        codigo: "Jo01jpga",
        img: "https://cdn-images.farfetch-contents.com/13/98/33/26/13983326_21706708_600.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },

       { 
     
        nombre:"Jordan R13",
        precio: "",
        categoria:"",
        codigo: "Jo02jpga",
        img: " https://img.clasf.co/2019/04/29/Jordan-Retro-13-Roj-para-Caballero-1-20190429060925.7111200015.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R13",
        precio: "",
        categoria:"",
        codigo: "Jo03jpga",
        img: "https://zap3bbb.cl/cdn/shop/products/JORDAN13RETRO_1_c8d8ca89-e4ae-44e3-b93a-cb9a2e4a553d.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R13",
        precio: "",
        categoria:"",
        codigo: "Jo04jpga",
        img: "https://static.nike.com/a/images/t_prod_ss/w_960,c_limit,f_auto/742452de-4a62-41dd-810d-3f4f922ed3ab/fecha-de-lanzamiento-de-las-air-jordan%C2%A013-court-purple-dj5982-015.jpg",
        provedores:"",
        color:"Negra/Morada ",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R13",
        precio: "",
        categoria:"",
        codigo: "Jo05jpga",
        img: "https://static.nike.com/a/images/t_prod_ss/w_960,c_limit,f_auto/2ecc27b5-3e3a-4b82-b485-aa237e9ebad4/fecha-de-lanzamiento-del-air-jordan-13-black-royal.jpg",
        provedores:"",
        color:" Negra/Azul",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R13",
        precio: "",
        categoria:"",
        codigo: "Jo06jpga",
        img: "https://static.nike.com/a/images/t_prod_ss/w_960,c_limit,f_auto/59052f3b-f867-45a8-93ae-26166af4f68c/fecha-de-lanzamiento-del-air-jordan-13-wheat-414571-171.jpg",
        provedores:"",
        color:"Blanco/Beige ",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R4",
        precio: "",
        categoria:"",
        codigo: "Jo07jpga",
        img: "https://libur.com.co/cdn/shop/files/IMG_4007_fc8778e3-443a-4991-a54e-adac055a068d.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R4",
        precio: "",
        categoria:"",
        codigo: "Jo08jpga",
        img: "https://libur.com.co/cdn/shop/files/IMG_2679_e827941e-8892-4f2e-b137-489f448f57f6.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       { 
         
        nombre:"Jordan R4 ",
        precio: "",
        categoria:"",
        codigo: "Jo09jpga",
        img: "https://paratishop.com/wp-content/uploads/2021/09/Hb0a9a1cf979b4285ad378d7e8b64f9c0j.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       { 
     
        nombre:"Jordan R4",
        precio: "",
        categoria:"",
        codigo: "Jo10jpga",
        img: "https://s3.amazonaws.com/images.kicksfinder.com/products/large/3b2958a4f266bd5d89c3eee17e53852a_1660354362.jpeg",
        provedores:"",
        color:" ",
        calidad :"",

       },

       
       { 
         
        nombre:"Jordan R4",
        precio: "",
        categoria:"",
        codigo: "Jo11jpga",
        img: "https://e1.pxfuel.com/desktop-wallpaper/433/419/desktop-wallpaper-air-jordans-4-travis-scott-jordan-retro-4-travis-scott.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       
       { 
         
        nombre:"jordan R4",
        precio: "",
        categoria:"",
        codigo: "Jo12jpga",
        img: "https://www.copncop.com/1934-large_default/air-jordan-4-frozen-moments.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
    


   

       { 
     
        nombre:"Jordan R6",
        precio: "",
        categoria:"",
        codigo: "Jo13jpga",
        img: "https://zshopp.com/wp-content/uploads/2020/02/71EC9PEubGL._UL1500_.jpg",
        provedores:"",
        color:" ",
        calidad :"",

       },
       { 
         
        nombre:"Jordan",
        precio: "110.00",
        categoria:"",
        codigo: "Jo14jpga",
        img: "https://s.yimg.com/zp/MerchandiseSpec/AC2A009CB1-SP-12713837.jpg",
        provedores:"",
        color:" ",
        calidad :"",
        
       },

       { 
         
        nombre:"adidas superstar",
        precio: "90.000 ",
        categoria:"DEPORTIVO",
        codigo: "Ad01jpga",
        img1: " https://assets.adidas.com/images/w_383,h_383,f_auto,q_auto,fl_lossy,c_fill,g_auto/2756c1aa61094ec283101d2910ed4196_9366/tenis-adidas-vl-court-3.0-low-skateboarding.jpg",
        provedores:"NACIONALES",
        color:" BCO/NG ",
        calidad :"AAA",
       },

       { 
        
           nombre:" adidas superstar",
           precio: "80.000",
           categoria:"",
           codigo: "Ad02jpga",
           img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/bd8f7ae244774097a60bab0300bea8de_9366/Tenis_Superstar_UNISEX_Negro_EF5394_01_standard.jpg",
           provedores:"",
           color:" NG/BCO ",
           calidad :"AAA",
          },

          { 
        
           nombre:"adidas superstar",
           precio: "80.000",
           categoria:"",
           codigo: "Ad03jpga",
           img: "https://falabella.scene7.com/is/image/FalabellaCO/4321050_1?wid=800&hei=800&qlt=70",
           provedores:"NACIONALES",
           color:" ",
           calidad :"AAA",
          },

          { 
        
           nombre:"adidas superstar",
           precio: "80.000",
           categoria:"",
           codigo: "Ad04jpga",
           img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/2e7642ed30e04c47a57faf680163ac9e_9366/Tenis_Superstar_PRIDE_RM_Blanco_ID7493_01_standard.jpg",
           provedores:"",
           color:" ",
           calidad :"",
          },

          { 
        
           nombre:"adidas superstar",
           precio: "80.000",
           categoria:"deportivos",
           codigo: "Ad05jpga",
           img: "https://assets.adidas.com/images/w_600,f_auto,q_auto/fb717f12d14c4d268ef8ac6a01695391_9366/Tenis_Superstar_Bold_Rojo_FZ1836_01_standard.jpg",
           provedores:"nacionales ",
           color:"negra/jamaica",
           calidad :"AAA",
          },

          { 
        
           nombre:"YEZZY",
           precio: "90.000",
           categoria:"DEPORTIVOS",
           codigo: "Ad06jpga",
           img: "https://images.stockx.com/images/adidas-Yeezy-Boost-350-V2-Onyx-Product.jpg?fit=fill&bg=FFFFFF&w=700&h=500&fm=webp&auto=compress&q=90&dpr=2&trim=color&updated_at=1656420652",
           provedores:"NACIONALES",
           color:"NEGRA",
           calidad :"AAA",
          },

          { 
        
           nombre:"YEZZY",
           precio: "90.000",
           categoria:"DEPORTIVOS",
           codigo: "Ad07jpga",
           img: "https://cdn.sneakers123.com/release/449648/conversions/adidas-yeezy-boost-350-v2-hq2060-thumb.jpg",
           provedores:"NACINALES",
           color:"VERDE",
           calidad :"AAA",
          },

          { 
        
           nombre:"YEZZY",
           precio: "90.000",
           categoria:"DEPORTIVOS",
           codigo: "Ad08jpga",
           img: "https://nevnev.co.il/wp-content/uploads/2022/06/Adidas-Yeezy-Boost-350-V2-Dazzling-Blue-nevnev.co_.il-3.jpg",
           provedores:"NACIONALES",
           color:"BLACO/AZUL",
           calidad :"AAA",
          },

          { 
        
           nombre:"YEZZY",
           precio: "90.000",
           categoria:"DEPORTIVOS",
           codigo: "Ad09jpga",
           img: "https://acdn.mitiendanube.com/stores/001/750/876/products/modelo-tenis-site-copia41-3deae402cae909e27216636045119814-1024-1024.jpg",
           provedores:"NACIONALES",
           color:" AZUL" ,
           calidad :"AAA",
          },

          { 
        
           nombre:"YEZZY",
           precio: "90.000",
           categoria:"DEPORTIVOS",
           codigo: "Ad10jpga",
           img: "https://cdn-images.farfetch-contents.com/15/47/78/06/15477806_27920430_600.jpg",
           provedores:"NACIONALES",
           color:" ",
           calidad :"AAA",
          },

          { 
        
           nombre:"ZAMBA",
           precio: "100.00",
           categoria:"CLASICAS",
           codigo: "Ad11jpga",
           img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/3bbecbdf584e40398446a8bf0117cf62_9366/Tenis_Samba_OG_Blanco_B75806_01_standard.jpg",
           provedores:"NACIONALES",
           color:" BLANCA/NEGRA/CAFE",
           calidad :"1.1",
          },

          { 
        
           nombre:"ZAMBA",
           precio: "100.00",
           categoria:"CLASICAS",
           codigo: "Ad12jpga",
           img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4a46e180c40643c8b436af9c017a4615_9366/Tenis_Samba_adidas_Originals_Verde_ID2054_01_standard.jpg",
           provedores:"NACIONALES",
           color:"VERDE/BLANCO/CAFE",
           calidad :"1.1",
          },

          { 
        
           nombre:"ZAMBA",
           precio: "100.00",
           categoria:"CLASICAS",
           codigo: "Ad13jpga",
           img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/eb4fe70570824a5993f305aca11473de_9366/Tenis_Samba_Verde_IG1242_01_standard.jpg",
           provedores:"NACIONALES",
           color:" VERDE ",
           calidad :"1.1",
          },

          { 
        
           nombre:"ZAMBA",
           precio: "100.00",
           categoria:"CLASICAS",
           codigo: "Ad14jpga",
           img: "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/d4f828e8d13044c484a0f3e617b1d80f_9366/Tenis_Samba_Premium_Gris_IE4957_01_standard.jpg",
           provedores:"NACIONALES",
           color:" GRIS",
           calidad :"1.1",
          },

          { 
        
           nombre:"ZAMBA",
           precio: "100.000",
           categoria:"CLASICAS",
           codigo: "Ad15jpga",
           img: "https://assets.adidas.com/images/w_600,f_auto,q_auto/4c70105150234ac4b948a8bf01187e0c_9366/Tenis_Samba_OG_Negro_B75807_01_standard.jpg",
           provedores:"NACIONALES",
           color:" NEGRAS",
           calidad :"1.1",
           
  
          },

         
          { 
        
           nombre:"Puma Roma",
           precio: "120.00",
           categoria:"CLASICAS",
           codigo: "Pm01jpga",
           img: "https://ss237.liverpool.com.mx/xl/1123801098.jpg",
           provedores:"",
           color:"NEGRAS",
           calidad :"1.1",
  
          },

          { 
        
           nombre:"Puma Roma",
           precio: "120.000",
           categoria:"Clasica",
           codigo: "Pm02jpga",
           img: "https://unicosmoderna.com/cdn/shop/products/TENIS-ROMA-BASIC-353572-58-HOMBRE-BLANCO-B.jpg",
           provedores:"Nacionales",
           color:"Blanco",
           calidad :"1.1",
  
          },
       

          { 
        
           nombre:"Puma Roma",
           precio: "120.000",
           categoria:"Clasica",
           codigo: "Pm03jpga",
           img: "https://i.ebayimg.com/thumbs/images/g/5jIAAOSwFbZjeDGJ/s-l640.jpg",
           provedores:"Nacionales",
           color:"Azul",
           calidad :"1.1",
  
          },
       

          { 
        
           nombre:"Puma Roma",
           precio: "120.000",
           categoria:"Clasica",
           codigo: "Pm04jpga",
           img: "https://i.ebayimg.com/thumbs/images/g/x8sAAOSwHkdjSfNO/s-l640.jpg",
           provedores:"NACIONALES",
           color:"ARCOIRIS",
           calidad :"1.1",
  
          },
       

          { 
        
           nombre:"Puma Roma",
           precio: "",
           categoria:"Clasica",
           codigo: "Pm05jpga",
           img: "https://resources.claroshop.com/medios-plazavip/s2/11633/3767207/628ffc7f4b773-7261cf23-b6fb-4301-b8cd-c5037979de6b-1600x1600.jpg",
           provedores:"",
           color:" NEGRA/ROJO ",
           calidad :"1.1",
  
          },
       

          { 
        
           nombre:"Puma California",
           precio: "100.000",
           categoria:"Clasicas",
           codigo: "Pm06jpga",
           img: "https://s7d9.scene7.com/is/image/zumiez/pdp_hero/PUMA-California-Exotic-Tan%2C-Gum-/u0026-White-Shoes-_302817.jpg",
           provedores:"Nacionales",
           color:"blanco",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma California",
           precio: "100.000",
           categoria:"clasicas",
           codigo: "Pm07jpga",
           img: "https://t-static.dafiti.com.br/y15P9TZ1g673TR2jvTc23K-WaJY=/400x580/smart/filters:quality(90)/static.dafiti.com.co/p/puma-0432-1905601-3-product.jpg",
           provedores:"Nacionales",
           color:" blanco/negro",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma California",
           precio: "100.000",
           categoria:"CLasica",
           codigo: "Pm08jpga",
           img: "https://scene7.zumiez.com/is/image/zumiez/image/PUMA-California-Black-%26-White-Shoes-_308420.jpg",
           provedores:"Nacionales",
           color:"negra/blanca",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma California",
           precio: "100.000",
           categoria:"Clasica",
           codigo: "Pm09jpga",
           img: "https://i.pinimg.com/564x/38/f8/fb/38f8fb9c1ae2559e03af9462cd4bcd4d.jpg",
           provedores:"Nacionales",
           color:" gris",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma California",
           precio: "100.000",
           categoria:"Clasicas",
           codigo: "Pm10jpga",
           img:" https://di2ponv0v5otw.cloudfront.net/posts/2023/04/06/642eb66b27539d699055bf52/m_642eb67bbd66cd9bdcdc6691.jpeg",
           provedores:"NAcionales",
           color:"Blanco/Azul",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma California",
           precio: "100.000",
           categoria:"Clasica",
           codigo: "Pm11jpga",
           img: "https://scene7.zumiez.com/is/image/zumiez/pdp_hero/PUMA-California-Casual-zapatos-blancos-y-rojos--_296520.jpg",
           provedores:"Nacional",
           color:"Blaco/Rojo ",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma Roma bmw",
           precio: "110.000",
           categoria:"Clasica",
           codigo: "Pm12jpga",
           img: "https://i.ebayimg.com/thumbs/images/g/qVIAAOSwBxhkQu24/s-l300.jpg",
           provedores:"Nacionales",
           color:"Negro/Rojo ",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma Ferrary",
           precio: "110.000",
           categoria:"Clasica",
           codigo: "Pm13jpga",
           img: "https://www.genetic.com.mx/cdn/shop/products/025475_1_600x600.jpg",
           provedores:"Nacionales",
           color:"Negra/Roja",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Puma ferrary",
           precio: "110.000",
           categoria:"Clasica",
           codigo: "Pm14jpga",
           img: "https://i5.walmartimages.com.mx/mg/gm/3pp/asr/9985913c-4522-453a-8beb-98d41ee0e444.1d36c283eeed1297c75eaf3f7342280c.jpeg",
           provedores:"Nacionales",
           color:" Rojo",
           calidad :"AAA",
  
          },
       

          { 
        
           nombre:"Pma Ferrary",
           precio: "110.000",
           categoria:"Clasica",
           codigo: "Pm15jpga",
           img: "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_450,h_450/global/306869/02/sv01/fnd/EEA/fmt/png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },

          { 
        
           nombre:"Jordan R13",
           precio: "",
           categoria:"",
           codigo: "Jo01jpga",
           img: "https://cdn-images.farfetch-contents.com/13/98/33/26/13983326_21706708_600.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },

          { 
        
           nombre:"Jordan R13",
           precio: "",
           categoria:"",
           codigo: "Jo02jpga",
           img: " https://img.clasf.co/2019/04/29/Jordan-Retro-13-Roj-para-Caballero-1-20190429060925.7111200015.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R13",
           precio: "",
           categoria:"",
           codigo: "Jo03jpga",
           img: "https://zap3bbb.cl/cdn/shop/products/JORDAN13RETRO_1_c8d8ca89-e4ae-44e3-b93a-cb9a2e4a553d.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R13",
           precio: "",
           categoria:"",
           codigo: "Jo04jpga",
           img: "https://static.nike.com/a/images/t_prod_ss/w_960,c_limit,f_auto/742452de-4a62-41dd-810d-3f4f922ed3ab/fecha-de-lanzamiento-de-las-air-jordan%C2%A013-court-purple-dj5982-015.jpg",
           provedores:"",
           color:"Negra/Morada ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R13",
           precio: "",
           categoria:"",
           codigo: "Jo05jpga",
           img: "https://static.nike.com/a/images/t_prod_ss/w_960,c_limit,f_auto/2ecc27b5-3e3a-4b82-b485-aa237e9ebad4/fecha-de-lanzamiento-del-air-jordan-13-black-royal.jpg",
           provedores:"",
           color:" Negra/Azul",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R13",
           precio: "",
           categoria:"",
           codigo: "Jo06jpga",
           img: "https://static.nike.com/a/images/t_prod_ss/w_960,c_limit,f_auto/59052f3b-f867-45a8-93ae-26166af4f68c/fecha-de-lanzamiento-del-air-jordan-13-wheat-414571-171.jpg",
           provedores:"",
           color:"Blanco/Beige ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R4",
           precio: "",
           categoria:"",
           codigo: "Jo07jpga",
           img: "https://libur.com.co/cdn/shop/files/IMG_4007_fc8778e3-443a-4991-a54e-adac055a068d.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R4",
           precio: "",
           categoria:"",
           codigo: "Jo08jpga",
           img: "https://libur.com.co/cdn/shop/files/IMG_2679_e827941e-8892-4f2e-b137-489f448f57f6.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R4 ",
           precio: "",
           categoria:"",
           codigo: "Jo09jpga",
           img: "https://paratishop.com/wp-content/uploads/2021/09/Hb0a9a1cf979b4285ad378d7e8b64f9c0j.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan R4",
           precio: "",
           categoria:"",
           codigo: "Jo10jpga",
           img: "https://s3.amazonaws.com/images.kicksfinder.com/products/large/3b2958a4f266bd5d89c3eee17e53852a_1660354362.jpeg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },

          { 
        
           nombre:"Jordan",
           precio: "",
           categoria:"",
           codigo: "Jo11jpga",
           img: "https://e1.pxfuel.com/desktop-wallpaper/433/419/desktop-wallpaper-air-jordans-4-travis-scott-jordan-retro-4-travis-scott.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
       
       

          { 
        
           nombre:"jordan R4",
           precio: "",
           categoria:"",
           codigo: "Jo12jpga",
           img: "https://www.copncop.com/1934-large_default/air-jordan-4-frozen-moments.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
       
  

      

          { 
        
           nombre:"Jordan R6",
           precio: "",
           categoria:"",
           codigo: "Jo13jpga",
           img: "https://zshopp.com/wp-content/uploads/2020/02/71EC9PEubGL._UL1500_.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
          { 
        
           nombre:"Jordan",
           precio: "110.00",
           categoria:"",
           codigo: "Jo14jpga",
           img: "https://s.yimg.com/zp/MerchandiseSpec/AC2A009CB1-SP-12713837.jpg",
           provedores:"",
           color:" ",
           calidad :"",
           
          },

          { 
        
           nombre:"jordan",
           precio: "",
           categoria:"",
           codigo: "Jo15jpga",
           img: "https://s1.dswcdn.com/uploads/Nike_Air_Jordan_Shoes/Air_Jordan_VI_6_Shoes/Air_Jordan_VI_High/Air_Jordan_6_PSG_Iron_Grey_Infrared_23_Black_CK1229-001.jpg",
           provedores:"",
           color:" ",
           calidad :"",
  
          },



          { 
        
           nombre:"nike ",
           precio: "",
           categoria:"",
           codigo: "Ni01jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/a66fbbfc-5658-4bfb-a108-44709d903ee3/calzado-cortez-vVqNKk.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike ",
           precio: "",
           categoria:"",
           codigo: "Ni02jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/23c7f6fe-1b94-4064-b779-5117c59347f5/calzado-cortez-mFmNVn.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike ",
           precio: "100.00",
           categoria:"",
           codigo: "Ni03jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/778064b0-bf66-4f4e-b7b9-7435288396ab/tenis-cortez-vintage-suede-nQSpJ7.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni04jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/0eba8e75-b5e4-4c02-9110-3b400e693b51/tenis-cortez-txt-6XHS74.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni05jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/3b094e32-b372-4208-b02a-029e3236ae70/tenis-cortez-23-premium-leather-0FZSGV.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike for one",
           precio: "",
           categoria:"",
           codigo: "Ni06jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/d75ffce9-db5f-4364-bd32-e076b84e1487/tenis-air-force-1-07-HDw18d.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni07jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/f8dfa191-60b3-44c1-b730-b25e0a908c35/tenis-air-force-1-07-easyon-vpmlK3.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni08jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/60d2e87c-9eaa-46a0-b9aa-0f730291262b/calzado-air-force-1-07-rXkGJX.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni09jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/3e9f4fa4-1765-4c4d-b480-dd059ebf2f40/force-1-low-easyon-zapatillas-nino-a-pequeno-a-6nbSNZ.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike R1",
           precio: "",
           categoria:"",
           codigo: "Ni10jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/fdeb34c8-a6bf-4530-9145-b6cfea5dd963/tenis-air-force-1-07-lv8-1-x0bMdL.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni11jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/312b0732-3206-40fa-b578-7bfb62c0675a/tenis-air-jordan-1-retro-high-og-JHpxkn.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni12jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/a4e485b4-02bd-4d24-9002-2f5a090e99a9/calzado-grandes-air-jordan-1-high-og-yellow-ochre-Wqf4f4.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni13jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/85f4973d-4233-45f7-8a74-b6c155f87c06/calzado-grandes-air-jordan-1-mid-H5qqbF.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },


          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni14jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/192bd1e3-9fd1-4f94-9f0e-799e443357e9/tenis-air-jordan-1-low-rJrHLw.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },

          { 
        
           nombre:"nike",
           precio: "",
           categoria:"",
           codigo: "Ni15jpga",
           img: "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/296839a0-9bd6-4c1c-b79b-055476793c29/calzado-air-jordan-1-retro-high-sp-1QS3rN.png",
           provedores:"",
           color:" ",
           calidad :"",
  
          },
    
       { 
     
        nombre:"YEZZY",
        precio: "90.000",
        categoria:"DEPORTIVOS",
        codigo: "Ad07jpga",
        img: "https://cdn.sneakers123.com/release/449648/conversions/adidas-yeezy-boost-350-v2-hq2060-thumb.jpg",
        provedores:"NACINALES",
        color:"VERDE",
        calidad :"AAA",
       }
       
       

];

document.getElementById('searchButton').addEventListener('click', function() {
    const query = document.getElementById('inputModalSearch').value.toLowerCase();
    const filteredProducts = productos.filter(producto => 
        producto.nombre.toLowerCase().includes(query) || 
        producto.precio.toLowerCase().includes(query) ||
        producto.categoria.toLowerCase().includes(query) ||
        producto.codigo.toLowerCase().includes(query) ||
        producto.provedores.toLowerCase().includes(query) ||
        producto.color.toLowerCase().includes(query) ||
        producto.calidad.toLowerCase().includes(query)
    );
    displayResults(filteredProducts);
});

function displayResults(filteredProducts) {
    const resultsContainer = document.getElementById('results');
    resultsContainer.innerHTML = ''; // Limpiar resultados anteriores

    if (filteredProducts.length > 0) {
        filteredProducts.forEach(producto => {
            const productDiv = document.createElement('div');
            productDiv.classList.add('product');
            productDiv.innerHTML = `
                <img src="${producto.img}" alt="${producto.nombre}">
                <div>
                    <h2>${producto.nombre}</h2>
                    <p>Precio: ${producto.precio}</p>
                    <p>Categoría: ${producto.categoria}</p>
                    <p>Código: ${producto.codigo}</p>
                    <p>Proveedores: ${producto.provedores}</p>
                    <p>Color: ${producto.color}</p>
                    <p>Calidad: ${producto.calidad}</p>
                </div>
            `;
            resultsContainer.appendChild(productDiv);
        });
    } else {
        resultsContainer.innerHTML = '<p>No se encontraron productos.</p>';
    }
}