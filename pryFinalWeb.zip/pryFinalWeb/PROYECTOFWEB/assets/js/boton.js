const cards = document.querySelectorAll('.card');
    
    let currentPage = 0;

    function showPage(page) {
        const start = page *45;
        const end = start + 45;
        cards.forEach((card, index) => {
            if (index >= start && index < end) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    function previousPage() {
        if (currentPage > 0) {
            currentPage--;
            showPage(currentPage);
        }
    }

    function nextPage() {
        const maxPage = Math.ceil(cards.length / 45) - 1;
        if (currentPage < maxPage) {
            currentPage++;
            showPage(currentPage);
        }
    }

    showPage(currentPage);