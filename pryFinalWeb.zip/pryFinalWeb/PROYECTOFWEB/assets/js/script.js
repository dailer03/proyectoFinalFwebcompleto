document.addEventListener('DOMContentLoaded', () => {
  const registrationForm = document.getElementById('registrationForm');
  const clearFieldsBtn = document.getElementById('clearFields');
  const viewProductsBtn = document.getElementById('viewProducts');

  registrationForm.addEventListener('submit', (e) => {
      e.preventDefault();
      registerProduct();
  });

  clearFieldsBtn.addEventListener('click', () => {
      registrationForm.reset();
  });

  viewProductsBtn.addEventListener('click', () => {
      window.location.href = 'products.html';
  });

  function registerProduct() {
      const name = document.getElementById('name').value;
      const category = document.getElementById('category').value;
      const imageInput = document.getElementById('image');
      const code = document.getElementById('code').value;
      const price = document.getElementById('price').value;
      const attribute1 = document.getElementById('attribute1').value;
      const attribute2 = document.getElementById('attribute2').value;
      const attribute3 = document.getElementById('attribute3').value;

      const reader = new FileReader();
      reader.onload = function(e) {
          const imageSrc = e.target.result;
          const product = {
              name,
              category,
              imageSrc,
              code,
              price,
              attribute1,
              attribute2,
              attribute3
          };
          saveProduct(product);
      };
      reader.readAsDataURL(imageInput.files[0]);
  }

  function saveProduct(product) {
      let products = JSON.parse(localStorage.getItem('products')) || [];
      products.push(product);
      localStorage.setItem('products', JSON.stringify(products));
  }
});